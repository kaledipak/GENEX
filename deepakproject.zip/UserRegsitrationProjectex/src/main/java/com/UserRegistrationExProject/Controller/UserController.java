package com.UserRegistrationExProject.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.UserRegistrationExProject.Entity.UserRegister;
import com.UserRegistrationExProject.service.UserService;


@Controller
public class UserController {

	@Autowired
	UserService sf;
	
	
	@GetMapping("/")
	public String showlogin()
	{
		return "login";
	}
	
	
	
	@RequestMapping("showRegister")
	public String showRegister()
	{
		return "Userreg";
	}
	
	@RequestMapping("saveData")
	ModelAndView saveData(UserRegister userreg)
	{	
	return sf.saveData(userreg);
	}
	
	
	@RequestMapping("checkLogin")
	public ModelAndView checkLogin(UserRegister userFromBrowser)
	{
	return sf.checkLogin(userFromBrowser);		
		
	}
}
