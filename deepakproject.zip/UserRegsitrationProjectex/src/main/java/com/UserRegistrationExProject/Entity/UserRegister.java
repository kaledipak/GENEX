package com.UserRegistrationExProject.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserRegister {
	
	
	@Id
	String username;
	String password;
	String confirmpass;
	String firstname;
	String lastname;
	String gender;
	String country;
	
	public UserRegister() {
	
		
	}

	
	
	public UserRegister(String username, String password, String confirmpass, String firstname, String lastname,
			String gender, String country) {
		this.username = username;
		this.password = password;
		this.confirmpass = confirmpass;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.country = country;
	}






	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getConfirmpass() {
		return confirmpass;
	}



	public void setConfirmpass(String confirmpass) {
		this.confirmpass = confirmpass;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}
	
	
	@Override
	public String toString() {
		return "UserRegister [username=" + username + ", password=" + password + ", confirmpass=" + confirmpass
				+ ", firstname=" + firstname + ", lastname=" + lastname + ", gender=" + gender + ", country=" + country
				+ "]";
	}

	

}
