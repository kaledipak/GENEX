package com.UserRegistrationExProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.UserRegistrationExProject.Dao.UserRepository;
import com.UserRegistrationExProject.Entity.UserRegister;


@Service
public class UserService {
	
	@Autowired
	UserRepository usr;

	public ModelAndView saveData(UserRegister userreg) {
	
		return usr.saveData(userreg);
	}
	
	
	public ModelAndView checkLogin(UserRegister userFromBrowser)
	{
	return usr.checkLogin(userFromBrowser);
	}


}
