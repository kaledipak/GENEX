package com.UserRegistrationExProject.Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.UserRegistrationExProject.Entity.UserRegister;


@Repository
public class UserRepository {
	
	
	@Autowired
	SessionFactory sf;

	public ModelAndView saveData(UserRegister user)
	{
		
		ModelAndView modelview = new ModelAndView();
		
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		
		session.save(user);
		
		tx.commit();
		
		
		modelview.addObject("message", "Congrat..Your Registration Successfully Done");
		modelview.setViewName("login");
		
		return modelview;
		
	}
	

	public ModelAndView checkLogin(UserRegister userFromBrowser)
	{
		ModelAndView mview = new ModelAndView();
		
		Session session = sf.openSession();
		
		UserRegister userFromDatabase = session.load(UserRegister.class, userFromBrowser.getUsername());
		if(userFromDatabase!=null)
		{
		if(userFromBrowser.getPassword().equals(userFromDatabase.getPassword()))
		{
			mview.addObject("message", "Your Login Successfully Done..");
			mview.setViewName("login");
		}
		
		
		else
		{
			mview.addObject("message", "Oops..Wrong Password");
			mview.setViewName("login");
		}
		}
		else
		{
			mview.addObject("message", "Oops..Wrong Username");
			mview.setViewName("login");	
		}
	
		return mview;
		
	}
}
	
	
	
	

